# -*- coding: utf-8 -*-

def agregar_guiones(cuit):
    # Convertir el CUIT a cadena si no lo es
    cuit_str = str(cuit)
    
    # Asegurarse de que el CUIT es suficientemente largo
    if len(cuit_str) < 4:
        return "El CUIT es demasiado corto para agregar guiones."
    
    # Agregar guion en la tercera posición y en la anteúltima posición
    cuit_modificado = cuit_str[:2] + '-' + cuit_str[2:-1] + '-' + cuit_str[-1]
    
    return cuit_modificado

# Ejemplo de uso
cuit = 20234033426
resultado = agregar_guiones(cuit)
print(resultado)  # Salida: 20-23403342-6