# -*- coding: utf-8 -*-
from selenium.webdriver.support import expected_conditions as EC
import os
import time
import pyautogui
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import pandas as pd
from openpyxl import Workbook
from selenium.webdriver.common.keys import *
import claves_fiscales
import threading
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
# Configurar opciones de Chrome para usar la impresora "Microsoft Print to PDF"
chrome_options = Options()
chrome_options.add_argument('--kiosk-printing')

driver= r'webdriver//chromedriver.exe'

#RUTA DE DESCARGA DEL EXCEL MIS COMPROBANTES

ruta_descarga=r'C:\Users\SOLO OUTLOOK\Desktop\promedios' #ACA SE PUEDE CAMBIAR CON UN INPUT
chromeOptions = webdriver.ChromeOptions()
prefs = {"download.default_directory" :  ruta_descarga}
chromeOptions.add_experimental_option("prefs",prefs)
driver = webdriver.Chrome(executable_path=driver, options=chromeOptions)
  


df = pd.read_csv("cuits.csv", encoding="latin-1")


#f=open("cuit_factu.csv","r")
for row, datos in df.iterrows():  
    h=open("CATEGORIAS.csv","a")   
    cuit_sociedad = str(datos['CUIT SOCIEDAD'])
    nombre_emisor = str(datos['NOMBRE'].encode('ascii', 'ignore').decode('ascii'))
    cuitreal=str(datos['CUIT'])   
#    print("-"+cuit+"-","-"+clave+"-")
    #time.sleep(1)
    driver.get('https://auth.afip.gob.ar/contribuyente_/login.xhtml')
    driver.maximize_window()
    # INGRESAR CUIT
    driver.find_element("xpath", '/html/body/main/div/div/div/div/div/div/form/div[1]/input').clear()
    driver.find_element("xpath", '/html/body/main/div/div/div/div/div/div/form/div[1]/input').send_keys(cuitreal)
    # SIGUIENTE
    driver.find_element("xpath", '/html/body/main/div/div/div/div/div/div/form/input[2]').click()
    # CLAVE FISCAL
    claves_fiscales.clave_fiscal(cuitreal)  
#try:
    driver.find_element("xpath", '/html/body/main/div/div/div/div/div/div/form/div/div[1]/input').send_keys(claves_fiscales.clave_fiscal(cuitreal))
    #INGRESAR
    driver.find_element("xpath", '/html/body/main/div/div/div/div/div/div/form/div/input[2]').click()
    time.sleep(1) 
    try:
        driver.find_element("xpath", '/html/body/div[2]/div[2]/div/div/div[3]/div/button[1]').click()
    except:
        pass
    time.sleep(1)     
    #MIS COMPROBANTES
    driver.find_element("xpath", '/html/body/div/div/div[2]/section/div/div/div[2]/div/div/div/div/div/div[1]/input').click()
    time.sleep(1)
    driver.find_element("xpath", '/html/body/div/div/div[2]/section/div/div/div[2]/div/div/div/div/div/div[1]/input').send_keys('Sistema Registral')
    time.sleep(1)
    driver.find_element("xpath", '/html/body/div/div/div[2]/section/div/div/div[2]/div/div/div[1]/div/div/ul/li[1]/a/div/div/div[1]/div/p').click()
    time.sleep(2)
            
    window_before = driver.window_handles[0]
    window_after = driver.window_handles[1]    
    driver.close()
    driver.switch_to.window(window_after)   

    def agregar_guiones(cuit):
        # Convertir el CUIT a cadena si no lo es
        cuit_str = str(cuit)
        
        # Asegurarse de que el CUIT es suficientemente largo
        if len(cuit_str) < 4:
            return "El CUIT es demasiado corto para agregar guiones."
        
        # Agregar guion en la tercera posición y en la anteúltima posición
        cuit_modificado = cuit_str[:2] + '-' + cuit_str[2:-1] + '-' + cuit_str[-1]
        
        return cuit_modificado

    # Ejemplo de uso
    cuit = cuitreal
    resultado_cuit = agregar_guiones(cuit)

    print(resultado_cuit)

    def agregar_guiones(cuitsociedad):
        # Convertir el CUIT a cadena si no lo es
        cuit_str = str(cuitsociedad)
        
        # Asegurarse de que el CUIT es suficientemente largo
        if len(cuit_str) < 4:
            return "El CUIT es demasiado corto para agregar guiones."
        
        # Agregar guion en la tercera posición y en la anteúltima posición
        cuit_modificado = cuit_str[:2] + '-' + cuit_str[2:10] + '-' + cuit_str[10:]
        
        return cuit_modificado

    # Ejemplo de uso
    cuitsociedad = cuit_sociedad
    resultado_cuitsociedad= agregar_guiones(cuitsociedad)
    
    print(resultado_cuitsociedad)


    try:
        # Espera hasta que el elemento que contiene el CUIT esté presente
        xpath_cuit = "//div[text()='CUIT {}']".format(resultado_cuit)
        elemento_cuit = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, xpath_cuit))
        )

        # Desplázate hasta el elemento
        driver.execute_script("arguments[0].scrollIntoView(true);", elemento_cuit)

        # Asegúrate de que el elemento esté clickable
        elemento_cuit = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, xpath_cuit))
        )

        # Usa JavaScript para hacer clic en el elemento
        driver.execute_script("arguments[0].click();", elemento_cuit)
    except Exception as e:
        print("No se pudo hacer clic en el elemento:", e)


 
    break